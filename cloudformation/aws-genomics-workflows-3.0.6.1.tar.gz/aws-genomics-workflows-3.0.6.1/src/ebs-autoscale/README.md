# Amazon Elastic Block Store Autoscale

## RELOCATION NOTICE

The code for this daemon has been moved to the following repoository:
[awslabs/amazon-ebs-autoscale](https://github.com/awslabs/amazon-ebs-autoscale)
