# Step Functions Workflow Examples

THIS IS A STUB

![Example Workflow](./images/example-state-machine.png)

this was created from [this file](./files/example-state-machine.json).